#include "stdafx.h"
#include "projectqjson.h"

//Fenêtre principale

ProjectQjson::ProjectQjson(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);

    ptrJson = new CJson; //Instanciation d'un objet de cette classe pour le traitement des données json
    ptrItemList = new CItemList(this, ptrJson, ui.itemList); //Instanciation d'un objet de cette classe pour répartir les tâches
}

ProjectQjson::~ProjectQjson()
{}


//Quand on appuie sur le bouton d'ajout de question
void ProjectQjson::on_addQuestionButton_clicked()
{
    //Ouverture de la boîte de dialogue
    textDialog dialog(this);
    if (dialog.exec())
    {
        //Récupération des données
        QString content = dialog.questionLine->text();
        QString type = "Question";

        //formatage json
        QJsonObject jsonData = ptrJson->jsonifyQuestion(content);

        //ajout du widget à la liste
        if (content != "") { ptrItemList->addItem(type,jsonData); }
    };
}


//Quand on appuie sur le bouton d'ajout d'image
void ProjectQjson::on_addPictureButton_clicked()
{
    //Ouverture de la boîte de dialogue
    picDialog dialog(this);
    if (dialog.exec())
    {
        //Récupération des données
        QString fileName = dialog.fileLabel->text();
        QString picTime = dialog.timeEdit->text();
        QString type = "Picture";

        //formatage json
        QJsonObject jsonData = ptrJson->jsonifyPicture(fileName, picTime);

        //ajout du widget à la liste
        if (jsonData != "") { ptrItemList->addItem(type, jsonData); }
    };
}


//Quand on appuie sur le bouton d'édition du widget
void ProjectQjson::on_editButton_clicked()
{
    //Saisir l'item sélectionné
    QListWidgetItem* curItem = ui.itemList->currentItem();

    //Déterminer son type et utiliser la méthode de traitement correspondante
    if (curItem->text() == "Question") 
    { 
        QJsonObject jsonData = curItem->data(Qt::UserRole).toJsonObject();
        QString text = ptrJson->getQstText(jsonData);
        ptrItemList->editQuestion(curItem, text);
    }
    if (curItem->text() == "Picture")
    {
        QJsonObject jsonData = curItem->data(Qt::UserRole).toJsonObject();
        QString fileName = ptrJson->getPicName(jsonData);
        QString time = ptrJson->getPicTime(jsonData);
        ptrItemList->editPicture(curItem, fileName, time);
    }

    //Mettre à jour l'affichage
    on_itemList_currentItemChanged();
}


//Quand on appuie sur le bouton de suppression d'un widget
void ProjectQjson::on_deleteButton_clicked()
{
    ptrItemList->deleteSelectedItem();
}


//Quand on appuie sur le bouton de génération du fichier json
void ProjectQjson::on_jsonButton_clicked()
{
    //Prendre les informations des widgets uns par uns et les ajouter au tableau d'animation
    for (int i = 0; i < ui.itemList->count(); i++)
    {
        QListWidgetItem* item = ui.itemList->item(i);
        QJsonObject data = item->data(Qt::UserRole).toJsonObject();
        ptrJson->addJson(data);
    };
    
    //Créer le document json et trouver son lieu de sauvegarde et son nom de fichier
    QJsonDocument content = ptrJson->compile();
    QString saveFile = QFileDialog::getSaveFileName(this, tr("Save File"), "", tr("text files (*.json)"));

    //Ecrire dans le fichier à l'endroit choisi
    QFile file(saveFile);

    if (file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        file.write(content.toJson());
        file.close();
    };
}


//Quand on appuie sur le bouton d'import de fichier json
void ProjectQjson::on_importButton_clicked()
{
    //Vider la liste de widgets
    ui.itemList->clear();

    //Choisir le fichier et le lire
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open File"), "", tr("JSON files (*.json)"));
    
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QByteArray byteFile = file.readAll();
        file.close();

        //extraire les objets json animation du fichier et les ajouter en tant que widgets
        QJsonDocument jsonDoc = QJsonDocument::fromJson(byteFile.data());
        QJsonObject object = jsonDoc.object();
        QJsonArray animArray = object.value("animation").toArray();
        QJsonObject jsonData;
        QString jsonKey;

        for(const QJsonValue valArray: animArray)
        {
            for (QString key : valArray.toObject().keys())
            {
                jsonData = valArray.toObject();
                jsonKey = key;
                ptrItemList->addItem(key, jsonData);
            }
        }
    }
}


//rafraichissement automatique de l'affichage des données du widget sélectionné
void ProjectQjson::on_itemList_currentItemChanged()
{
    //Saisir le widget sélectionné
    QListWidgetItem* curItem = ui.itemList->currentItem();

    //Si un widget est sélectionné
    if (curItem)
    {
        //conversion des données json du widget en string utilisable et affichage
        QJsonObject jsonData = curItem->data(Qt::UserRole).toJsonObject();
        QString dataString = ptrJson->jsonDataToString(jsonData);
        ui.resultLabel->setText("Type: " + curItem->text() + " Data: " + dataString);

        //Déblocage des boutons d'édition et de suppression
        ui.deleteButton->setDisabled(false);
        ui.editButton->setDisabled(false);
    }
    //Si il n'y a pas de widget sélectionné
    else
    {
        //Vider l'affichage et désactiver les boutons
        ui.resultLabel->setText(">");
        ui.deleteButton->setDisabled(true);
        ui.editButton->setDisabled(true);
    }
}
