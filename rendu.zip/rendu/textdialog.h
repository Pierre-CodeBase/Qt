#pragma once

#include <QDialog>
#include "ui_textdialog.h"

class textDialog : public QDialog, public Ui::textDialogClass
{
	Q_OBJECT

public:
	textDialog(QWidget *parent = nullptr);
	~textDialog();

private:
	 
};

