#include "stdafx.h"
#include "picdialog.h"

//Boîte de dialogue pour saisir le nom du fichier image et son temps d'apparition

picDialog::picDialog(QWidget *parent)
	: QDialog(parent)
{
	setupUi(this);
}

picDialog::~picDialog()
{}

//Vérifier que les champs ne sont pas vides ou invalides
void picDialog::on_confirmButton_clicked()
{
	if (fileLabel->text() != "" && fileLabel->text() != "Fichier image manquant") {
		if (timeEdit->text() != "" && timeEdit->text() != "0")
		{
			accept();
		}

		else
		{
			timeEdit->setFocus();
		}
	}

	else 
	{
		fileLabel->setText("Fichier image manquant");
		searchButton->setFocus();
	}
}

//Ouvrir l'explorateur de fichier pour sélectionner le fichier image
void picDialog::on_searchButton_clicked()
{
	QString filePath = QFileDialog::getOpenFileName(this, tr("Open File"), "", tr("image files (*.jpeg *.jpg *.png)"));

	//Enextraire le nom du fichier
	QFileInfo fileInfo(filePath);
	QString fileName = fileInfo.fileName();

	if (fileName != "") {
		fileLabel->setText(fileName);
	};
}