#pragma once
#include "stdafx.h"

#include <QtWidgets/QApplication>
#include <qjsondocument.h>
#include <string>

#include "ui_projectqjson.h"

#include "CJson.h"
#include "CItemList.h"
#include "projectqjson.h"

#include "textdialog.h"
#include "picdialog.h"
