#pragma once
#include "predef.h"

using std::string;

class CJson
{
private:
	QJsonArray animation;
	QJsonArray equipes;

public:
	CJson();
	~CJson();
	QString jsonDataToString(QJsonObject& jsonObj);
	QString getQstText(QJsonObject& jsonObj);

	QString fromPictJson(QJsonObject& jsonObj);
	QString getPicName(QJsonObject& jsonObj);
	QString getPicTime(QJsonObject& jsonObj);


	QJsonObject jsonifyQuestion(QString& content);
	QJsonObject jsonifyPicture(QString& fileName, QString& time);

	void addJson(QJsonObject& question);
	void clearJson(QJsonArray& jsonArr);
	QJsonDocument compile();
};
