#pragma once
#include "predef.h"

class CJson;
class CItemList;

class ProjectQjson : public QMainWindow
{
    Q_OBJECT

public:
    ProjectQjson(QWidget *parent = nullptr);
    ~ProjectQjson();

private:
    Ui::ProjectQjsonClass ui;
    CJson* ptrJson;
    CItemList* ptrItemList;

public slots:
    void on_itemList_currentItemChanged();

private slots:
    void on_addQuestionButton_clicked();
    void on_addPictureButton_clicked();
    void on_editButton_clicked();
    void on_deleteButton_clicked();
    void on_jsonButton_clicked();
    void on_importButton_clicked();
};

