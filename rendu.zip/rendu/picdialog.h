#pragma once

#include <QDialog>
#include "ui_picdialog.h"

class picDialog : public QDialog, public Ui::picDialogClass
{
	Q_OBJECT

public:
	picDialog(QWidget *parent = nullptr);
	~picDialog();

private:

private slots:
	void on_searchButton_clicked();
	void on_confirmButton_clicked();
	 
};

