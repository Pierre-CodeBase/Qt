#include "stdafx.h"
#include "CItemList.h"

//Cette classe à pour objectif de traiter les tâches se rapportant à la liste des widgets sur la fenâtre principale

CItemList::CItemList(ProjectQjson* ptrProject, CJson* ptrCJson, QListWidget* ptrProjectList)
{
    //relations avec les objets de CJson (traitement json), QListWidget (liste des widgets), ProjectQJson (fenêtre principale)
    this->ptrMain = ptrProject;
    this->ptrList = ptrProjectList;
    this->ptrJson = ptrCJson;
}

//Ajouter un widget à la liste
void CItemList::addItem(QString& type, QJsonObject& jsonData)
{
    QListWidgetItem* item = new QListWidgetItem(type, ptrList);
    item->setData(Qt::UserRole, jsonData);
    ptrList->setCurrentItem(item);
}

//editer un widget type question
void CItemList::editQuestion(QListWidgetItem * curItem, QString & text)
{
    //Envoyer les infos précedentes à la boîte de dialogue
    textDialog dialog(ptrMain);
    dialog.questionLine->setText(text);

    //Ouvrir la boîte de dialogue et récupérer les infos sur validation
    if (dialog.exec())
    {
        QString type = "Question";
        QString content = dialog.questionLine->text();

        //appel à l'objet de la classe CJson pour créer un json à partir des infos
        QJsonObject jsonData = ptrJson->jsonifyQuestion(content);

        //affecter les nouvelles infos au widget
        if (content != "") { curItem->setData(Qt::UserRole, jsonData); }
    }
}

//editer un widget type image
void CItemList::editPicture(QListWidgetItem * curItem, QString& fileName, QString& time)
{
    //Envoyer les infos précedentes à la boîte de dialogue
    picDialog dialog(ptrMain);
    dialog.fileLabel->setText(fileName);
    dialog.timeEdit->setText(time);

    //Ouvrir la boîte de dialogue et récupérer les infos sur validation
    if (dialog.exec())
    {
        QString fileName = dialog.fileLabel->text();
        QString picTime = dialog.timeEdit->text();
        QString type = "Picture";

        //appel à l'objet de la classe CJson pour créer un json à partir des infos
        QJsonObject jsonData = ptrJson->jsonifyPicture(fileName, picTime);

        //affecter les nouvelles infos au widget
        if (jsonData != "") { curItem->setData(Qt::UserRole, jsonData); }
    };
}

//Supprimer un widget de la liste
void CItemList::deleteSelectedItem()
{
    QListWidgetItem* curItem = ptrList->currentItem();

    if (curItem)
    {
        //Suppression du widget en localisant son numéro de ligne
        int row = ptrList->row(curItem);
        ptrList->takeItem(row);
        delete curItem;

        //Mettre à jour la sélection s'il reste des widgets dans la liste
        if (ptrList->count() > 0)
        {
            ptrList->setCurrentRow(row - 1);
        }
        //Sinon, mettre à jour l'affichage
        else
        {
            ptrMain->on_itemList_currentItemChanged();
        }
    }    
}
