#include "stdafx.h"
#include "textdialog.h"

//Boîte de dialogue pour saisir le texte d'une question

textDialog::textDialog(QWidget *parent)
	: QDialog(parent)
{
	setupUi(this);
}

textDialog::~textDialog()
{}

