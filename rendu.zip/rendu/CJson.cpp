#include "stdafx.h"
#include "CJson.h"

//Le but de cette classe est le traitement des données en json
//Instanciation par la fenêtre principale objet de ProjectQJson

CJson::CJson()
{
    //Création des objets tableaux racines
    this->animation = QJsonArray();
    this->equipes = QJsonArray();
}

CJson::~CJson()
{}


//Identifier le contexte en identifiant la clé de l'objet
QString CJson::jsonDataToString(QJsonObject& jsonObj)
{
    QString dataString;

    for (const QString key : jsonObj.keys())
    {
        //Renvoyer à la bonne méthode de traitement
        if (key == "Question") { dataString = "Texte: " + getQstText(jsonObj); };
        if (key == "Picture") { dataString = fromPictJson(jsonObj); };
    }

    return dataString;
}


//Extraire le texte du json type question
QString CJson::getQstText(QJsonObject& jsonObj)
{
    QString strData;

    strData = jsonObj.value("Question").toString();

    return strData;
}


//Formater les informations d'image en un seul QString
QString CJson::fromPictJson(QJsonObject& jsonObj)
{
    QString strData;

    strData = "Name: " + getPicName(jsonObj) + " Time:" + getPicTime(jsonObj);

    return strData;
}


//Extraire le nom du fichier image du json type image
QString CJson::getPicName(QJsonObject& jsonObj)
{
    QString strData;

    strData = jsonObj.value("Picture").toArray().at(0).toObject().value("Name").toString();

    return strData;
}


//Extraire le temps d'apparition du json type image
QString CJson::getPicTime(QJsonObject& jsonObj)
{
    QString strData;

    strData = jsonObj.value("Picture").toArray().at(1).toObject().value("Time").toString();

    return strData;
}


//Convertir le texte de question en structure json
QJsonObject CJson::jsonifyQuestion(QString& text)
{
    QJsonObject jsonQstObj;
    jsonQstObj.insert("Question",text);
    return jsonQstObj;
}


//Convertir le nom du fichier et le temps d'apparition en structure json
QJsonObject CJson::jsonifyPicture(QString& fileName, QString& time)
{
    QJsonObject jsonPicObj;
    QJsonArray jsonPicArr;
    QJsonObject jsonPicName;
    QJsonObject jsonPicTime;

    jsonPicName.insert("Name", fileName);
    jsonPicTime.insert("Time", time);
    jsonPicArr.push_back(jsonPicName);
    jsonPicArr.push_back(jsonPicTime);
    jsonPicObj.insert("Picture", jsonPicArr);

    return jsonPicObj;
}


//Ajouter une structure json au tableau d'animation
void CJson::addJson(QJsonObject& jsonData)
{
    animation.push_back(jsonData);
}


//Effacer un tableau json
void CJson::clearJson(QJsonArray& jsonArr)
{
    while (jsonArr.count())
    {
        jsonArr.pop_back();
    }
}


//Compiler un document json à partir du tableau d'animation
QJsonDocument CJson::compile()
{
    QJsonObject recordObject;

    recordObject.insert("animation", animation);
    clearJson(animation);

    QJsonDocument jsonDoc(recordObject);

    return jsonDoc;
}