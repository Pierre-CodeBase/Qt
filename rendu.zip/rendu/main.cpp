#include "stdafx.h"
#include "predef.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    ProjectQjson window;
    window.show();
    return app.exec();
}
