#pragma once
#include "predef.h"

class ProjectQjson;
class CJson;

class CItemList
{
private:
	ProjectQjson * ptrMain;
	QListWidget * ptrList;
	CJson* ptrJson;

public:
	CItemList(ProjectQjson* ptrProject, CJson* ptrCJson, QListWidget* ptrProjectList);

	void addItem(QString& type, QJsonObject& jsonData);

	void editQuestion(QListWidgetItem* curItem, QString& text);
	void editPicture(QListWidgetItem* curItem, QString& fileName, QString& time);

	void deleteSelectedItem();
};

